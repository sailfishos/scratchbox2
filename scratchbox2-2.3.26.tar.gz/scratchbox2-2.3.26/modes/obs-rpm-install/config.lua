-- Copyright (c) 2012 Nokia Corporation.
-- Author: Lauri T. Aarnio
-- Licensed under MIT license.
--
-- Common config for the "obs-rpm-install" mode

enable_cross_gcc_toolchain = false

