/* Automatically generated file. Do not edit. */
#include "libsb2.h"
#include "privatewrappers.h"
static char * (*getenv_next__)(const char *varname) = NULL;

char *getenv(const char *varname)
{
	char * ret = NULL;
	int saved_errno = errno;
	int result_errno = saved_errno;
	const uint32_t classmask = 0;
	(void)classmask; /* ok, if it isn't used */
	errno = 0;
	SB_LOG(SB_LOGLEVEL_DEBUG,"%s(%s)",__func__,varname);
	if(getenv_next__ == NULL) {
		getenv_next__ = sbox_find_next_symbol(1, "getenv");
		if (getenv_next__ == NULL) {
			SB_LOG(SB_LOGLEVEL_ERROR, "Real '%s' not found", "getenv");
			abort();
		}
	}
	errno = saved_errno;
	ret = (*getenv_next__)(varname); result_errno = errno;
	SB_LOG(SB_LOGLEVEL_NOISE, "%s returns '%s', errno=%d (%s)", __func__, (ret ? ret : "<NULL>"), result_errno, (saved_errno != result_errno ?  "SET" : "unchanged") );
	errno = result_errno;
	return(ret);
}

static int (*unsetenv_next__)(const char *varname) = NULL;

int unsetenv(const char *varname)
{
	int ret = -1;
	int saved_errno = errno;
	int result_errno = saved_errno;
	const uint32_t classmask = 0;
	(void)classmask; /* ok, if it isn't used */
	errno = 0;
	SB_LOG(SB_LOGLEVEL_DEBUG,"%s(%s)",__func__,varname);
	if(unsetenv_next__ == NULL) {
		unsetenv_next__ = sbox_find_next_symbol(1, "unsetenv");
		if (unsetenv_next__ == NULL) {
			SB_LOG(SB_LOGLEVEL_ERROR, "Real '%s' not found", "unsetenv");
			abort();
		}
	}
	errno = saved_errno;
	ret = (*unsetenv_next__)(varname); result_errno = errno;
	SB_LOG(SB_LOGLEVEL_NOISE, "%s returns %d, errno=%d (%s)", __func__, ret, result_errno, (saved_errno != result_errno ?  "SET" : "unchanged") );
	errno = result_errno;
	return(ret);
}

static int (*setenv_next__)(const char *varname, const char *value, int overwrite_flag) = NULL;

int setenv(const char *varname, const char *value, int overwrite_flag)
{
	int ret = -1;
	int saved_errno = errno;
	int result_errno = saved_errno;
	const uint32_t classmask = 0;
	(void)classmask; /* ok, if it isn't used */
	errno = 0;
	SB_LOG(SB_LOGLEVEL_DEBUG,"%s(%s)",__func__,varname);
	if(setenv_next__ == NULL) {
		setenv_next__ = sbox_find_next_symbol(1, "setenv");
		if (setenv_next__ == NULL) {
			SB_LOG(SB_LOGLEVEL_ERROR, "Real '%s' not found", "setenv");
			abort();
		}
	}
	errno = saved_errno;
	ret = (*setenv_next__)(varname, value, overwrite_flag); result_errno = errno;
	SB_LOG(SB_LOGLEVEL_NOISE, "%s returns %d, errno=%d (%s)", __func__, ret, result_errno, (saved_errno != result_errno ?  "SET" : "unchanged") );
	errno = result_errno;
	return(ret);
}

interface_function_and_classes_t interface_functions_and_classes__private[] = {
	{"getenv", 0},
	{"setenv", 0},
	{"unsetenv", 0},
	{NULL, 0},
};
