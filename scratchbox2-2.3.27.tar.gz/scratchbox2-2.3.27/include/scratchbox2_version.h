/* Automatically generated file. Do not edit. */
#define SCRATCHBOX2_VERSION "2.3.18-dirty"
#define LIBSB2_SONAME "libsb2.so.1"
