/* Automatically generated file. Do not edit. */
#ifndef PRELOAD_PRIVATEWRAPPERS_H__
#define PRELOAD_PRIVATEWRAPPERS_H__

#include <sys/utsname.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <sys/user.h>
#include <sys/mman.h>

#include <assert.h>
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>
#include <dirent.h>
#include <string.h>
#include <glob.h>
#include <utime.h>
#ifdef HAVE_FTS_H
#include <fts.h>
#endif
#ifdef HAVE_FTW_H
#include <ftw.h>
#endif
#ifdef HAVE_SHADOW_H
#include <shadow.h>
#endif
#ifdef HAVE_SYS_XATTR_H
#include <sys/xattr.h>
#endif

#include "mapping.h"

#if (defined(PROPER_DIRENT) && (PROPER_DIRENT == 1))
typedef const struct dirent *scandir_arg_t;
typedef const struct dirent64 *scandir64_arg_t;
#else
typedef const void scandir_arg_t;
typedef const void scandir64_arg_t;
#endif

extern char *getenv(const char *varname); /* (WRAP) */
extern char *getenv_nomap(const char *varname);
extern char *getenv_nomap_nolog(const char *varname);
extern int unsetenv(const char *varname); /* (WRAP) */
extern int unsetenv_nomap(const char *varname);
extern int unsetenv_nomap_nolog(const char *varname);
extern int setenv(const char *varname, const char *value, int overwrite_flag); /* (WRAP) */
extern int setenv_nomap(const char *varname, const char *value, int overwrite_flag);
extern int setenv_nomap_nolog(const char *varname, const char *value, int overwrite_flag);

#endif
