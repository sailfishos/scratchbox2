/* Copyright (C) 2011 Nokia Corporation.
 * Author: Lauri T. Aarnio
*/

#ifndef SB2_RULETREE_LUA_H__
#define SB2_RULETREE_LUA_H__

/* ------------ rule_tree_luaif.c: ------------ */
extern int lua_bind_ruletree_functions(lua_State *l);

#endif /* SB2_RULETREE_LUA_H__ */

